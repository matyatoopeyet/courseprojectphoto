package com.example.matveicourseproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
